Compiling the espeakedit program.

You need the "espeakedit" download,

Copy the source files from the "espeakedit" download into directory "src",
but do not overwrite files:
  speech.h
  StdAfx.h

There are copies of these in directory "src_copy".


Use the  "Unicode Release" build configuration.
This links with the "Unicode Release" version of the wxWidgets libraries.
